user_pref('browser.tabs.remote.autostart', false);
user_pref('browser.tabs.remote.autostart.1', false);
user_pref('browser.tabs.remote.autostart.2', false);
